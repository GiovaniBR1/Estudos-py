# Neste algoritmo, crie uma variável que armazene uma string e uma lista que armazena várias strings.
