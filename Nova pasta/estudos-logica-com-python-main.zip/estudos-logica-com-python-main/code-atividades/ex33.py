#Função com parametros
def soma(a, b):
    return a + b

resultado = soma(3, 5)
print(resultado)