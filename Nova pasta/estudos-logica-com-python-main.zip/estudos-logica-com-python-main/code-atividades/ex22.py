l1 = [2, 3, 5, 6]
l2 = l1.append(8)
print(l1)