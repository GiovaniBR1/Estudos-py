numero = 5
while numero <= 5:
    if numero < 5:
        numero += numero
    print(numero)