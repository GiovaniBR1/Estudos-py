# Lendo de um arquivo

with open('ex040.py', 'r') as arquivo:
    conteudo = arquivo.read()
    print(conteudo)