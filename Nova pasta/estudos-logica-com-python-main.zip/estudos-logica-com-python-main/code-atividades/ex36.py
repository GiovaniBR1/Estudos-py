#Bibliotecas
import datetime

hoje = datetime.date.today()
print("A data de hoje é: ", hoje)