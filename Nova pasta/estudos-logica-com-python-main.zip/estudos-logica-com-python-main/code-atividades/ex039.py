#Coletando entrada do usuário

nome = input('Qual é o seu nome?')
print(f"Olá, {nome}!")

#Saída formatada

idade = 31
print(f"Eu tenho {idade} anos.")