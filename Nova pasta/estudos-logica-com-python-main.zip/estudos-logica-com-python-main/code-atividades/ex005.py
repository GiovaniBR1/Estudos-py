#Cores no Terminal
print('\033[1;32;40mOlá, Mundo!')


